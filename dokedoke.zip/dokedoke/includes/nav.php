<header>
	<div class="navbar">
		<?php ansimuz_menu() ?>
	</div>
</header>
