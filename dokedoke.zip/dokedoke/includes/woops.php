<div class="woops">
	<h4><?php _e('Woops...','ansimuz') ?></h4>  
	<p><?php _e('Sorry, no posts were found.','ansimuz') ?></p> 
</div>