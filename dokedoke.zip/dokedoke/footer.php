		<?php get_template_part('includes/social-bar') ?>
		<?php get_template_part('includes/widgets-columns') ?>
		
		<!-- footer -->
		<footer>
			<div class="inner">
				<?php echo stripcslashes(get_option('ansimuz_footer')) ?>
			</div>
		</footer>
		<!-- ENDSfooter -->


	</div>
	<!-- ENDS main content -->
	


	

<?php wp_footer() ?>	
</body>
</html>